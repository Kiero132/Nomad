package ru.kiero.nomad;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import ru.kiero.nomad.init.NomadBlockEntities;
import ru.kiero.nomad.init.NomadBlocks;
import ru.kiero.nomad.init.NomadCreativeTab;
import ru.kiero.nomad.init.NomadItems;

@Mod("nomad")
public class Nomad {

    public static final String MOD_ID = "nomad";

    public Nomad() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        NomadBlocks.reg(modBus);
        NomadItems.reg(modBus);
        NomadCreativeTab.reg(modBus);
        NomadBlockEntities.reg(modBus);
    }
}
