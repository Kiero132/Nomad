package ru.kiero.nomad.blocks;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import ru.kiero.nomad.init.NomadBlockEntities;
import java.util.UUID;

public class TotemBlockEntity extends BlockEntity {

    private UUID uuid;

    private final ItemStackHandler items = new ItemStackHandler(2){
        @Override
        protected void onContentsChanged(int slot) {
            super.onContentsChanged(slot);
            setChanged();
        }

        @Override
        public boolean isItemValid(int slot, @NotNull ItemStack stack) {
            return super.isItemValid(slot, stack);
        }
    };

    public TotemBlockEntity(BlockPos pPos, BlockState pBlockState) {
        super(NomadBlockEntities.TOTEM.get(), pPos, pBlockState);

    }

    @Override
    protected void saveAdditional(CompoundTag pTag) {
        super.saveAdditional(pTag);
        //pTag.put("items", items.serializeNBT());
        pTag.putUUID("uuid", this.uuid);
    }

    @Override
    public void load(CompoundTag pTag) {
        super.load(pTag);
        //items.deserializeNBT(pTag.getCompound("items"));
        this.uuid = pTag.getUUID("uuid");
    }


}
