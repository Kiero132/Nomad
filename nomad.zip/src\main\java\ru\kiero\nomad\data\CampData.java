package ru.kiero.nomad.data;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import ru.kiero.nomad.Nomad;

import java.util.*;

public class CampData extends SavedData {

    private Map<UUID, CompoundTag> CAMPS = new HashMap<>();

    public static final String DATA_NAME = Nomad.MOD_ID + "_camp";

    @Override
    public CompoundTag save(CompoundTag pCompoundTag) {
        ListTag list = new ListTag();
        for(UUID uuid : CAMPS.keySet()){
            CompoundTag tag = new CompoundTag();
            tag.putLong("blockPos", CAMPS.get(uuid).getLong("blockPos"));

            //Friendship MAP<PlayerUUID, Integer>
            ListTag playerList = new ListTag();
            CompoundTag playerTag = new CompoundTag();

            for (int i=0; i<CAMPS.get(uuid).getList("friendship", ListTag.TAG_COMPOUND).size(); i++){
                playerTag.putUUID("playerUUID", CAMPS.get(uuid).getList("friendship", ListTag.TAG_COMPOUND).getCompound(i).getUUID("playerUUID"));
                playerTag.putInt("playerValue", CAMPS.get(uuid).getList("friendship", ListTag.TAG_COMPOUND).getCompound(i).getInt("value"));
                playerList.add(playerTag);
            }

            tag.put("friendship", playerList);

            tag.putInt("radius", CAMPS.get(uuid).getInt("radius"));
            tag.putString("name", CAMPS.get(uuid).getString("name"));
            tag.putInt("level", CAMPS.get(uuid).getInt("level"));


            list.add(tag);
        }
        pCompoundTag.put("data", list);
        return pCompoundTag;
    }

    private static CampData load(CompoundTag tag){
        CampData data = new CampData();
        ListTag list = tag.getList("data", ListTag.TAG_COMPOUND);

        for (int i=0; i<list.size(); i++){
            CompoundTag uuidTag = list.getCompound(i);
            CompoundTag tagP = new CompoundTag();

            tagP.putLong("blockPos", BlockPos.of(uuidTag.getLong("blockPos")).asLong());

            ListTag playerList = uuidTag.getList("friendship", ListTag.TAG_COMPOUND);
            ListTag newPlayerList = new ListTag();

            for (int j=0; j<playerList.size(); j++){
                CompoundTag playerTag = playerList.getCompound(i);
                CompoundTag newTag = new CompoundTag();

                newTag.putUUID("playerUUID", playerTag.getUUID("playerUUID"));
                newTag.putInt("playerValue", playerTag.getInt("playerValue"));
                newPlayerList.add(newTag);
            }
            tagP.put("friendship", newPlayerList);

            tagP.putInt("radius", uuidTag.getInt("radius"));
            tagP.putString("name", uuidTag.getString("name"));
            tagP.putInt("level", uuidTag.getInt("level"));

            data.CAMPS.put(uuidTag.getUUID("uuid"), tagP);
        }
        return data;
    }

    public static CampData get(ServerLevel serverLevel){
        return serverLevel.getDataStorage().computeIfAbsent(CampData::load, CampData::new, DATA_NAME);
    }

    public UUID createCamp(BlockPos blockPos){
        UUID uuid = UUID.randomUUID();
        CompoundTag tag = new CompoundTag();
        tag.putLong("blockPos", blockPos.asLong());
        tag.putInt("radius", getRadiusOf(1)); //Test radius
        tag.putString("name", nameGenerate());
        tag.putInt("level", 1);

        CAMPS.put(uuid, tag);
        setDirty();

        return uuid;
    }

    public void removeCamp(UUID uuid){
        if(CAMPS.containsKey(uuid)) CAMPS.remove(uuid);
        setDirty();
    }

    public UUID getCampAt(BlockPos pos){
        for (UUID uuid : CAMPS.keySet()){
            if(BlockPos.of(CAMPS.get(uuid).getLong("blockPos")).equals(pos)){
                return uuid;
            }
        }
        return null;
    }

    //Геттеры
    public BlockPos getBlockPos(UUID uuid)      {return BlockPos.of(CAMPS.get(uuid).getLong("blockPos"));}
    public int getRadius(UUID uuid)             {return CAMPS.get(uuid).getInt("radius");}
    public String getName(UUID uuid)            {return CAMPS.get(uuid).getString("name");}
    public int getLevelOf(UUID uuid)            {return CAMPS.get(uuid).getInt("level");}

    public int getRadiusOf(int level){
        return switch (level){
            case 1 -> 15;
            case 2 -> 25;
            case 3 -> 35;
            case 4 -> 45;
            case 5 -> 60;
            default -> 0;
        };
    }

    private String nameGenerate(){
        List<String> first = List.of("Серый", "Красный", "Северный", "Тихий", "Дикий", "Железный");
        List<String> second = List.of("Ветер", "Камень", "Волк", "Огонь", "Песок", "Орёл");

        Random rand = new Random();

        String res = first.get(rand.nextInt(first.size())) + " " + second.get(rand.nextInt(second.size()));
        return res;
    }
}
